<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('New Project')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl p-2 sm:rounded-lg">
                <div class="text-2xl flex  justify-center">
                    <div class="ring-[#FDBB3E] z-10 ring-2 text-[#FDBB3E] px-4 py-2 rounded-full">الخطوة الأولى</div>
                    <div class="h-12 w-12 rounded-full z-0 bg-[#7056A1] flex justify-center">
                        <p class="my-auto text-white font-extrabold">1</p>
                    </div>
                    

                </div>
                <div class="container p-2 w-1/3 mx-auto text-center text-[#7056A1]">
                    <form action="<?php echo e(route('projects.store')); ?>" method="post" class="relative ">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="org_id" class="block text-gray-700 text-lg mt-5 font-bold mb-2">اختر
                                العميل</label>
                            <bdi>
                                <select
                                    class="shadow appearance-none border-2 border-[#7056A1] rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                    name="org_id" id="org_id">
                                    <option>---</option>
                                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <optgroup label="<?php echo e($area->name); ?>">
                                            <?php $__currentLoopData = $area->organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($org->id); ?>"><?php echo e($org->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </optgroup>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </bdi>
                        </div>
                        <address id="address"></address>
                        <div>
                            <label for="deadline" class="block text-gray-700 text-lg mt-5 font-bold mb-2">الموعد النهائي
                                للمشروع</label>
                            <input
                                class="shadow appearance-none border-2 border-[#7056A1] rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                type="datetime-local" name="deadline" id="deadline">
                        </div>
                        <div class="">
                            <label for="description" class="block text-gray-700 text-lg mt-5 font-bold mb-2">تعليقات ووصف
                                للمشروع</label>
                            <textarea
                                class="shadow appearance-none border-2 border-[#7056A1] rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                name="description" id="description" cols="30" rows="10" ></textarea>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => []]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>التالي <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('footerScripts'); ?>
        <script type="text/javascript">
            console.log('hello')
            $("#org_id").change(function() {
                $.ajax({
                    url: "<?php echo e(route('organizations.get_by_id')); ?>?organization=" + $(this).val(),
                    method: 'GET',
                    success: function(data) {
                        $('#address').html(data.html);
                    }
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nour\Desktop\Nytrogin\nytrogin\resources\views/project/create.blade.php ENDPATH**/ ?>