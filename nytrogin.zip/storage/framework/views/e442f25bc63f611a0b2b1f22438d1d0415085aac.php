<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            تفاصيل مشروع <?php echo e($project->organization->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 px-6">
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-2">
            <div class="bg-white h-[250px] rounded-md p-6 flex flex-col border-2 border-[#E9EAEB]">
                <div class="flex justify-end w-full gap-3">
                    <span class="material-icons text-gray-400">
                        star_border
                    </span>
                    <span class="material-icons text-gray-400">
                        more_horiz
                    </span>
                </div>
                <div class="flex flex-col text-gray-800">
                    <h1 class="text-2xl ">
                        <?php echo e($project->organization->name); ?>

                    </h1>
                    <div class="flex gap-2 mt-3">
                        <div class="bg-green-100 tracking-tighter text-green-400 font-bold px-3 py-1 rounded-full">
                            فعالية حية
                        </div>
                    </div>
                </div>
                <div class="flex flex-col text-gray-500 font-normal mt-auto">
                    <p>بدء المشروع:
                        <span><?php echo e(\Carbon\Carbon::parse($project->created_at)->diffForHumans()); ?></span>
                    </p>
                    <p>تسليم المشروع:
                        <span><?php echo e(\Carbon\Carbon::parse($project->deadline)->diffForHumans()); ?></span>
                    </p>
                </div>
            </div>
            <div class="bg-white h-[250px] rounded-md p-6 grid grid-cols-2 col-span-2 gap-6 border-2 border-[#E9EAEB]">
                <div id="inspectors">
                    <h1 class="text-xl">المراقبين:</h1>
                    <?php $__empty_1 = true; $__currentLoopData = $project->inspectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$inspector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="<?php echo e($index % 2 ? 'bg-gray-100 rounded-xl' : ''); ?> p-3">
                            <?php echo e($inspector->user->name); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </div>
                <div id="supervisors">
                    <h1 class="text-xl">المشرفين:</h1>
                    <?php $__empty_1 = true; $__currentLoopData = $project->supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="<?php echo e($index % 2 ? 'bg-gray-100 rounded-xl' : ''); ?> p-3">
                            <?php echo e($supervisor->user->name); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo $__env->make('project.project_status',['checklist'=>$project->checklist], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="bg-white border-2 p-5 col-span-2 relative">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\ProjectChecklist::class)): ?>
                    <form id="new_inspection_item" class="flex">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="checklist_id" value="<?php echo e($project->checklist->id); ?>">

                        <div class="w-1/3">
                            <div class=" relative rounded-md shadow-sm ">
                                <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                    <span class="text-white rounded-full bg-[#FBBC41] sm:text-sm material-icons">
                                        add
                                    </span>
                                </div>
                                <input type="text" name="inspection_item" id="inspection_item"
                                    class="focus:ring-indigo-500 focus:border-indigo-500 block w-full h-full pr-10 pl-12 border-gray-300 rounded-md"
                                    placeholder="اضافة معيار جديد" autocomplete="off">
                            </div>
                        </div>
                        <input type="submit" value="إضافة"
                            class=" bg-[#71579A] my-auto text-white font-bold px-5 h-11 mr-4 rounded-md">
                    </form>
                <?php endif; ?>
                <form id="inspection_checklist" method="POST" action="<?php echo e(route('checklist.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <table class="min-w-full border border-collapse mt-4">
                        <thead>
                            <tr>
                                <th class="border py-4 w-4">رقم</th>
                                <th class="border py-4 w-1/2">المعيار</th>
                                <th class="border py-4 w-16">نعم</th>
                                <th class="border py-4 w-16">لا</th>
                                <th class="border py-4 w-16">لا ينطبق</th>
                                
                            </tr>
                        </thead>
                        <tbody id="inspection_rows">
                        </tbody>
                    </table>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\ProjectChecklist::class)): ?>
                        <?php if($project->checklist->status != 'pending' && $project->checklist->items->count() > 0): ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['type' => 'submit','class' => 'mt-4 bg-[#705998] tracking-tighter text-lg']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'mt-4 bg-[#705998] tracking-tighter text-lg']); ?>
                                حفظ القائمة
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php else: ?>
                            (بانتظار موافقة المشرفين)
                        <?php endif; ?>
                    <?php endif; ?>
                </form>
                <div class="flex justify-between py-2 text-lg">

                    <?php if(auth()->user()->role->id == \App\Models\Role::IS_SUPERVISOR && $project->checklist->status == 'pending'): ?>

                        <form action="<?php echo e(route('checklist.approve_checklist')); ?>" method="post">
                            <input type="hidden" value="<?php echo e($project->checklist->id); ?>" name="checklist_id">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'text-md tracking-tight bg-green-500']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-md tracking-tight bg-green-500']); ?>
                                موافقة
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </form>
                        <form action="<?php echo e(route('checklist.decline_checklist')); ?>" method="post">
                            <input type="hidden" value="<?php echo e($project->checklist->id); ?>" name="checklist_id">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'text-md tracking-tight bg-red-500']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-md tracking-tight bg-red-500']); ?>
                                رفض
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </form>
                    <?php else: ?>
                        <?php switch(explode($project->checklist->status,'_')[0]):
                            case ('approved'): ?>
                                <div class="text-xl text-green-500">
                                    <?php echo e(__($project->checklist->status)); ?>

                                </div>
                            <?php break; ?>
                            <?php case ('declined'): ?>
                                <div class="text-xl text-red-500">
                                    <?php echo e(__($project->checklist->status)); ?>

                                </div>
                            <?php break; ?>
                            <?php default: ?>
                        <?php endswitch; ?>
                    <?php endif; ?>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\ProjectChecklist::class)): ?>
                    <?php if($project->checklist->status != 'pending' && $project->checklist->items->count() > 0): ?>
                        <form action="<?php echo e(route('checklist.request_approval_from_supervisor')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($project->checklist->id); ?>" name="checklist_id">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['type' => 'submit','class' => 'mt-4 bg-[#FBBC41] tracking-tighter text-lg absolute left-4 bottom-4']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'mt-4 bg-[#FBBC41] tracking-tighter text-lg absolute left-4 bottom-4']); ?>
                                طلب الموافقة من المشرفين
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>


        </div>
    </div>
    <?php $__env->startSection('footerScripts'); ?>
        <script>
            let count = 0;
            $('#new_inspection_item').submit(function(event) {
                event.preventDefault();
                let row_text = $('#inspection_item').val();
                if (row_text == null || row_text.trim() == '') return;
                $.ajax({
                    url: "<?php echo e(route('checklist.add_checkitem')); ?>",
                    method: 'POST',
                    data: $('#new_inspection_item').serialize(),
                    success: function(data) {
                        $('#inspection_rows').html(data.html).fadeIn();
                        $('#inspection_item').val('');

                    }
                });
            });
            $.ajax({
                url: "<?php echo e(route('checklist.get_all_checkitems')); ?>?checklist_id=<?php echo e($project->checklist->id); ?>",
                method: 'get',
                success: data => {
                    $('#inspection_rows').html(data.html).fadeIn()
                }
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\nour\Desktop\Nytrogin\nytrogin\resources\views/project/show.blade.php ENDPATH**/ ?>