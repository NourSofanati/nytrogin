<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\nour\Desktop\Nytrogin\nytrogin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>